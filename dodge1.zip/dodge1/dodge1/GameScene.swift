//
//  GameScene.swift
//  dodge1
//
//  Created by J^3 on 4/19/16.
//  Copyright (c) 2016 J^3. All rights reserved.
//

import SpriteKit

struct physics{
    static let Enemy: UInt32 = 1
    static let Player: UInt32 = 3
    
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    var player = SKSpriteNode(imageNamed: "Heros/Player")
    var levelTimerLabel = SKLabelNode(fontNamed: "ArialMT")
    var timerCount: Int = 0{
    didSet {
    levelTimerLabel.text = "Survived: \(timerCount) seconds"
        }
    }
    

    func Enemies(){
    let Enemy = SKSpriteNode(imageNamed: "Enemies/Trump.png")
    let MinValue = self.size.width / 8
    let MaxValue = self.size.width - 20
    let SpawnPoint = UInt32(MaxValue - MinValue)
    Enemy.position = CGPoint(x: CGFloat(arc4random_uniform(SpawnPoint)), y: self.size.height)
    Enemy.physicsBody = SKPhysicsBody(rectangleOfSize: Enemy.size)
    Enemy.physicsBody?.affectedByGravity = false
    Enemy.physicsBody?.dynamic = true
    Enemy.physicsBody?.categoryBitMask = physics.Enemy
    Enemy.physicsBody?.contactTestBitMask = physics.Player
    
    let action = SKAction.moveToY(-70, duration: 2.0)
    let actionDone = SKAction.removeFromParent()
    Enemy.runAction(SKAction.sequence([action, actionDone]))
    
    self.addChild(Enemy)
    }
    
    override func didMoveToView(view: SKView) {
    physicsWorld.contactDelegate = self
    player.position = CGPointMake(self.size.width/2, self.size.height/5)
    player.physicsBody = SKPhysicsBody(rectangleOfSize: player.size)
    player.physicsBody?.affectedByGravity = false
    player.physicsBody?.categoryBitMask = physics.Player
    player.physicsBody?.contactTestBitMask = physics.Enemy
    player.physicsBody?.dynamic = false
    self.addChild(player)
    NSLog("sprite is here")
    
    var EnemyTimer = NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: Selector("Enemies"), userInfo: nil, repeats: true)
    
    levelTimerLabel.fontColor = SKColor.whiteColor()
    levelTimerLabel.fontSize = 40
    levelTimerLabel.position = CGPoint(x: size.width/2, y: size.height/2 - 350)
    self.addChild(levelTimerLabel)
    
    let wait = SKAction.waitForDuration(0.5) //change timer speed here
    let block = SKAction.runBlock({
    [unowned self] in
    
    if self.timerCount >= 0{
    self.timerCount++
    }
    else{
    self.removeActionForKey("Timer")
            }
        }
    )
    
    let sequence = SKAction.sequence([wait,block])
    runAction(SKAction.repeatActionForever(sequence), withKey: "Timer")
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
    let firstBody: SKPhysicsBody = contact.bodyA
    let secondBody: SKPhysicsBody = contact.bodyB
    
    if ((firstBody.categoryBitMask == physics.Enemy) && (secondBody.categoryBitMask == physics.Player)) || (firstBody.categoryBitMask == physics.Player) && (secondBody.categoryBitMask == physics.Enemy){
    collisionWithEnemy(firstBody.node as! SKSpriteNode, player: secondBody.node as! SKSpriteNode)
    NSLog("you've been hit")
        }
    }
    
    func collisionWithEnemy(Enemy: SKSpriteNode, player: SKSpriteNode){
    Enemy.removeFromParent()
    player.removeFromParent()
    NSLog("you died")
    let reveal = SKTransition.flipHorizontalWithDuration(0.5)
        if timerCount >= 10 {
    let gameOverScene = GameOverScene(size: self.size, won: true)
        gameOverScene.gameScene = self
        gameOverScene.timerCount = timerCount
        
    self.view?.presentScene(gameOverScene, transition: reveal)
        }
            
        else {
            let gameOverScene = GameOverScene(size: self.size, won: false)
            gameOverScene.gameScene = self
            gameOverScene.timerCount = timerCount
            
            self.view?.presentScene(gameOverScene, transition: reveal)
        }
        
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
    for touch in touches {
    let location = touch.locationInNode(self)
    player.position.x = location.x
        }
    }
    
    override func update(currentTime: CFTimeInterval) {

    }
}
