//
//  GameOver.swift
//  dodge1
//
//  Created by J^3 on 4/19/16.
//  Copyright (c) 2016 J^3. All rights reserved.
//

import UIKit
import SpriteKit

class GameOver: SKScene {

    override func didMoveToView(view: SKView) {
        NSLog("Game Over")
    }
    
}
